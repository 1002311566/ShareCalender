package com.yihuan.sharecalendar.modle.bean;

/**
 * Created by Ronny on 2017/9/6.
 */

public class BaseBean<T> {

    public int code;
    public String message;
    public T data;
}
