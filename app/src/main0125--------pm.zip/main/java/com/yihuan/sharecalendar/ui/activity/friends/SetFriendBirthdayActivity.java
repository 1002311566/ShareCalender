package com.yihuan.sharecalendar.ui.activity.friends;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.yihuan.sharecalendar.R;
import com.yihuan.sharecalendar.global.Constants;
import com.yihuan.sharecalendar.global.base.BaseActivity;
import com.yihuan.sharecalendar.global.base.BasePresenter;
import com.yihuan.sharecalendar.modle.bean.active.TimeBean;
import com.yihuan.sharecalendar.modle.bean.friend.MyFriendDetailBean;
import com.yihuan.sharecalendar.presenter.SetFriendBirthdayPresenter;
import com.yihuan.sharecalendar.presenter.contract.SetFriendBirthdayContract;
import com.yihuan.sharecalendar.ui.view.TitleView;
import com.yihuan.sharecalendar.ui.view.popwin.SolarPop;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by Ronny on 2017/12/9.
 * 备注好友生日
 */

public class SetFriendBirthdayActivity extends BaseActivity<SetFriendBirthdayPresenter> implements SetFriendBirthdayContract.View {
    @BindView(R.id.tv_solar_birthday)
    TextView tvSolarBirthday;
    @BindView(R.id.tv_lunar_birthday)
    TextView tvLunarBirthday;
    @BindView(R.id.cb_always_remind)
    CheckBox cbAlwaysRemind;//0: 否, 1: 是

    private String isAlways;//是否永久提醒
    private MyFriendDetailBean myFriendDetailBean;
    private String friendId= "";

    @Override
    protected BasePresenter setPresenter() {
        return new SetFriendBirthdayPresenter(this);
    }

    @Override
    protected void initTitleView(TitleView titleView) {
        titleView.setCenterText("备注好友生日");
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_set_friend_birthday;
    }

    @Override
    protected void initView() {
        myFriendDetailBean = (MyFriendDetailBean) getIntent().getSerializableExtra(Constants.INTENT_MY_FRIEND_DETAILS);
        if(myFriendDetailBean != null){
            friendId = myFriendDetailBean.getFriendId()+"";
            if(myFriendDetailBean.getIsPermenentRemind() != null){
                cbAlwaysRemind.setSelected(myFriendDetailBean.getIsPermenentRemind().equals("1"));
                isAlways = myFriendDetailBean.getIsPermenentRemind();
            }
        }
        setListener();
    }

    private void setListener() {
        cbAlwaysRemind.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                cbAlwaysRemind.setSelected(isChecked);
                isAlways = isChecked ? "1" : "0";
                mPresenter.setFriendBirthday(friendId, null, null, isAlways);
            }
        });
    }

    @Override
    protected void refreshData() {

    }

    public static void start(Activity activity, MyFriendDetailBean friendDetailBean){
        Intent intent = new Intent(activity, SetFriendBirthdayActivity.class);
        intent.putExtra(Constants.INTENT_MY_FRIEND_DETAILS, friendDetailBean);
        activity.startActivity(intent);
    }


    @OnClick({R.id.tv_solar_birthday, R.id.tv_lunar_birthday})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_solar_birthday://todo 新历生日
                showSolarBirthdayPop(view);
                break;
            case R.id.tv_lunar_birthday://todo 农历生日
                showLunarBirthdayPop(view);
                break;
        }
    }

    /**
     * 新历生日
     * @param view
     */
    private void showSolarBirthdayPop(View view) {
        final SolarPop solarPop = new SolarPop(this, view);
        solarPop.show();
        solarPop.setOnSelectDateListener(new SolarPop.OnSelectDateListener() {
            @Override
            public void onSelect(TimeBean timeBean) {
                mPresenter.setFriendBirthday(friendId,timeBean.toMD(), null, isAlways);
                solarPop.dismiss();
            }
        });
    }

    /**
     * 农历生日
     * @param view
     */
    private void showLunarBirthdayPop(View view) {
        final SolarPop solarPop = new SolarPop(this, view);
        solarPop.show();
        solarPop.setOnSelectDateListener(new SolarPop.OnSelectDateListener() {
            @Override
            public void onSelect(TimeBean timeBean) {
                mPresenter.setFriendBirthday(friendId,null, timeBean.toMD(), isAlways);
                solarPop.dismiss();
            }
        });
    }

    @Override
    public void onSetFriendBirthdayOK() {

    }
}
