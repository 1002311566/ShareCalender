package com.yihuan.sharecalendar.ui.view.calendar.week;

/**
 * Created by Jimmy on 2016/10/7 0007.
 */
public interface OnWeekClickListener {
    void onClickDate(int year, int month, int day);
}
