package com.yihuan.sharecalendar.modle.bean;

/**
 * Created by Ronny on 2018/1/22.
 */

public class JPushBean {

    /**
     * activityId : 990
     * type : activity
     */

    private String activityId;
    private String type;

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
