package com.yihuan.sharecalendar.ui.view.calendar.schedule;

/**
 * Created by Jimmy on 2016/10/8 0008.
 */
public enum ScheduleState {
    OPEN,
    CLOSE
}
