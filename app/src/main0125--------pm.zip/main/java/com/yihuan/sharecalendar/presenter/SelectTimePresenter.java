package com.yihuan.sharecalendar.presenter;

import com.yihuan.sharecalendar.global.base.BasePresenter;
import com.yihuan.sharecalendar.modle.bean.active.TimeBean;
import com.yihuan.sharecalendar.modle.data.DataSource;
import com.yihuan.sharecalendar.presenter.contract.SelectTimeContract;
import com.yihuan.sharecalendar.ui.activity.active.SelectTimeActivity;

import java.util.List;

/**
 * Created by Ronny on 2017/11/5.
 */

public class SelectTimePresenter extends BasePresenter<SelectTimeActivity> implements SelectTimeContract.Presenter {

    public SelectTimePresenter(SelectTimeActivity selectTimeActivity) {
        super(selectTimeActivity);
    }

    @Override
    public List<Integer> getYearData() {
        return DataSource.getYearData();
    }

    @Override
    public List<Integer> getMonthData() {
      return DataSource.getMonthData();
    }

    @Override
    public List<Integer> getDayData(int year, int month) {
        return DataSource.getDays(year, month);
    }

    @Override
    public List<Integer> getHourData() {
       return DataSource.getHourData();
    }

    @Override
    public List<Integer> getMinuteData() {
      return DataSource.getMinuteData();
    }

    @Override
    public TimeBean getCurrentTimeBean() {
        return DataSource.getCurrentTimeBean();
    }


    @Override
    public int getYearPosition(int year) {
        return DataSource.getYearPosition(year);
    }


    @Override
    public int getMonthPosition(int month) {
        return DataSource.getMonthPosition(month);
    }

    @Override
    public int getDayPosition(TimeBean timeBean) {
        return DataSource.getDayPosition(timeBean);
    }

    @Override
    public int getHourPosition(int hour) {
        return DataSource.getHourPosition(hour);
    }

    @Override
    public int getMinutePosition(int minute) {
        return DataSource.getMinutePosition(minute);
    }

    @Override
    public int getCurrentWeekPosition() {
        return DataSource.getCurrentWeekPosition();
    }
}
