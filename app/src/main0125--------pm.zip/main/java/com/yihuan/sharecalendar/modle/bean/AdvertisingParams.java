package com.yihuan.sharecalendar.modle.bean;

/**
 * Created by Ronny on 2017/12/29.
 * 广告参数
 */

public class AdvertisingParams {
    public String playType;//播放时机 , 1 页面弹出前、 2 页面关闭后
    public String exeType;//执行方式, 1: 全屏, 2: 弹屏
    public String adType;//广告类型: 广告类型: 1 心情广告 、3：消息退出广告
    public String exeLocation;//执行位置, 1: 心情指数界面, 2:消息界面
}
