package com.yihuan.sharecalendar.ui.view.other;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by Ronny on 2018/1/23.
 */

public class GridDividerItem extends RecyclerView.ItemDecoration {
   int spanCount;
    int mSpace;

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
//            super.getItemOffsets(outRect, view, parent, state);
            // 网格布局，从第二列开始，left = mSpace，从第二行开始 top = mSpace
            int pos = parent.getChildLayoutPosition(view);
            if (pos % spanCount != 0) {
                outRect.left = mSpace;
            }
            if (pos >= spanCount) {
                outRect.top = mSpace;
            }
        }

        public GridDividerItem(int space, int spanCount) {
            this.mSpace = space;
            this.spanCount = spanCount;
        }
}
