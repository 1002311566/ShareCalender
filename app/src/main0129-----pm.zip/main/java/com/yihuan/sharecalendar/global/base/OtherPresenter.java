package com.yihuan.sharecalendar.global.base;

/**
 * Created by Ronny on 2017/9/5.
 * 后期或添加功能
 */

public interface OtherPresenter {
}
