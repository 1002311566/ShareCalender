package com.yihuan.sharecalendar.modle.bean.active;

/**
 * Created by Ronny on 2017/12/16.
 */

public enum  ShareType {
    URL,TEXT;
}
