package com.yihuan.sharecalendar.ui.view.pickerview.listener;


import com.yihuan.sharecalendar.ui.view.pickerview.TimePickerDialog;

/**
 * Created by jzxiang on 16/4/20.
 */
public interface OnDateSetListener {

    void onDateSet(TimePickerDialog timePickerView, long millseconds);
}
