package com.yihuan.sharecalendar.ui.adapter.recyclerview.listener;

import android.support.v7.widget.RecyclerView;

/**
 * Created by Ronny on 2017/9/26.
 * 添加，删除
 */

public interface OnRvItemAddAndDeleteListener {
    void onAddClick();
    void onDeleteClick(RecyclerView.ViewHolder holder, int position);
}
