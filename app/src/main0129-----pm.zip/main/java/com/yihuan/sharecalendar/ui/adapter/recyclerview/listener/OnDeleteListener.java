package com.yihuan.sharecalendar.ui.adapter.recyclerview.listener;

/**
 * Created by Ronny on 2017/12/13.
 */

public interface OnDeleteListener {
    void onDelete();
}
