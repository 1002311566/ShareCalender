package com.yihuan.sharecalendar.modle.bean;

/**
 * Created by Ronny on 2018/1/2.
 */

public class AdvertisingTsBean {
    /**
     * adShowWay : 2
     * adFixedHourShow : 5
     * adSetting : 2
     */

    private String adShowWay;
    private int adFixedHourShow;
    private String adSetting;

    public String getAdShowWay() {
        return adShowWay;
    }

    public void setAdShowWay(String adShowWay) {
        this.adShowWay = adShowWay;
    }

    public int getAdFixedHourShow() {
        return adFixedHourShow;
    }

    public void setAdFixedHourShow(int adFixedHourShow) {
        this.adFixedHourShow = adFixedHourShow;
    }

    public String getAdSetting() {
        return adSetting;
    }

    public void setAdSetting(String adSetting) {
        this.adSetting = adSetting;
    }
}
