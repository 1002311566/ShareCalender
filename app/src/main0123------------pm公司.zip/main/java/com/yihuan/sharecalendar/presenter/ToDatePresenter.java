package com.yihuan.sharecalendar.presenter;

import com.yihuan.sharecalendar.global.base.BasePresenter;
import com.yihuan.sharecalendar.modle.bean.active.TimeBean;
import com.yihuan.sharecalendar.modle.data.DataSource;
import com.yihuan.sharecalendar.presenter.contract.ToDateContract;
import com.yihuan.sharecalendar.ui.activity.setting.ToDateActivity;

import java.util.List;

/**
 * Created by Ronny on 2017/11/5.
 */

public class ToDatePresenter extends BasePresenter<ToDateActivity> implements ToDateContract.Presenter {


    public ToDatePresenter(ToDateActivity toDateActivity) {
        super(toDateActivity);
    }

    @Override
    public List<Integer> getYearData() {
        return DataSource.getYearData();
    }

    @Override
    public List<Integer> getMonthData() {
      return DataSource.getMonthData();
    }

    @Override
    public List<Integer> getDayData(int year, int month) {
        return DataSource.getDays(year, month);
    }

    @Override
    public List<Integer> getHourData() {
       return DataSource.getHourData();
    }

    @Override
    public List<Integer> getMinuteData() {
      return DataSource.getMinuteData();
    }

    @Override
    public TimeBean getCurrentTimeBean() {
        return DataSource.getCurrentTimeBean();
    }


    @Override
    public int getCurrentYearPosition() {
        return DataSource.getCurrentYearPosition();
    }

    @Override
    public int getCurrentMonthPosition() {
        return DataSource.getCurrentMonthPosition();
    }

    @Override
    public int getCurrentDayPosition(TimeBean mSelectTime) {
        return DataSource.getDayPosition(mSelectTime);
    }

    @Override
    public int getCurrentHourPosition() {
        return DataSource.getCurrentHourPosition();
    }

    @Override
    public int getCurrentMinutePosition() {
        return DataSource.getCurrentMinutePosition();
    }

    @Override
    public int getCurrentWeekPosition() {
        return DataSource.getCurrentWeekPosition();
    }
}
