package com.yihuan.sharecalendar.utils;

/**
 * Created by Ronny on 2017/11/17.
 */

public class StringUtils {
    public static String nullToStr(String str) {
        return str == null ? "" : str;
    }
}
