package com.yihuan.sharecalendar.modle.db.active;


/**
 * Created by Ronny on 2017/11/12.
 * todo 新建日程流程：先进行本地数据库存储， 并打上标记为待上传（IS_TO_NET），刷新时查找所有待上传的日程，然后上传
 * todo             （服务器需要提供一个id字段存储这边的主键id），上传成功后根据主键id进行更新本地数据库
 * <p>
 * todo 删除日程流程：先进行网络删除，如果没有网络或删除失败，先在数据库打个被删除标记（IS_DELETE），等刷新时再继续删除，直到
 * todo              服务器删除成功，才去清空自己数据库的日程
 * <p>
 * todo 日程查询流程：先根据日期查找（条件：date 在 开始时间 <= date <= 结束时间 && 没有被删除标记 && ）
 */

public interface ActiveDBConfig {
    String TABBLE_NAME = "active";

    String USER_ID = "user_id";//用户id
    String PUBLISH_USER_ID = "publish_user_id";
    String ACTIVE_ID = "active_id";//活动id
    String TITLE = "title";//标题
    String LOCATION = "location";//位置
    String LON = "lon";//经度
    String LAT = "lat";//纬度
    String FULLDAY = "fullDay";//是否全天
    String START_YM = "startYM";//开始的日期
    String END_YM = "endYM";//结束日期
    String START_YMD = "startYMD";
    String END_YMD = "endYMD";
    String START_TIME = "startTime";//开始时间
    String END_TIME = "endTime";//结束时间
    String CYCLE = "cycle";//周期
    String REMIND = "remind";//提醒
    String DES = "des";//说明
    String SHARE_FRIEND = "share_friend";//共享好友
    String IS_SHARE_SCHDULE = "is_share_schdule";//是否是共享日程

    String CREATE_ACTIVE_TABLE = "create table " + TABBLE_NAME + "(" +
            ACTIVE_ID + " integer primary key," +
            USER_ID + " integer, " +
            PUBLISH_USER_ID + " integer," +
            TITLE + " text," +
            LOCATION + " text," +
            LON + " double," +
            LAT + " double," +
            FULLDAY + " integer," +
            START_YM + " text," +
            END_YM + " text," +
            START_YMD + " text," +
            END_YMD + " text," +
            START_TIME + " text," +
            END_TIME + " text," +
            CYCLE + " integer," +
            REMIND + " text," +
            DES + " text," +
            SHARE_FRIEND + " text," +
            IS_SHARE_SCHDULE + " text)";

    String DROP_ACTIVE_TABLE = "DROP TABLE " + TABBLE_NAME;
}
