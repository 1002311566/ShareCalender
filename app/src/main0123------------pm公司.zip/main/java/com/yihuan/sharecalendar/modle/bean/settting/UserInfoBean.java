package com.yihuan.sharecalendar.modle.bean.settting;

/**
 * Created by Ronny on 2017/9/9.
 * 自定义存储类
 */

public class UserInfoBean {
    public String sex;
    public String age;
    public String constellation;
    public int constellationId;
    public String address;
    public int addressId;
}
