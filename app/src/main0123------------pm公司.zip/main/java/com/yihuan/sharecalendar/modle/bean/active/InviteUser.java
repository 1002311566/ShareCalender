package com.yihuan.sharecalendar.modle.bean.active;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ronny on 2017/11/4.
 * 创建活动传入的共享好友参数
 */

public class InviteUser {
    public String inviteUser;
    public InviteUser(String inviteUser) {
        this.inviteUser = inviteUser;
    }
}
