package com.yihuan.sharecalendar.modle.bean.active;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ronny on 2017/12/13.
 * 发起者--邀请好友
 */

public class InviteFriendBean {
    public int activeId;
    public List<Integer> inviteUserIds = new ArrayList<>();
}
