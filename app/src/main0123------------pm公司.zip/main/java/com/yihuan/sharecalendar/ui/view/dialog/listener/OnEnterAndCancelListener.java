package com.yihuan.sharecalendar.ui.view.dialog.listener;

/**
 * Created by Ronny on 2018/1/10.
 */

public interface OnEnterAndCancelListener {
    void onCancel();
    void onEnter();
}
