package com.yihuan.sharecalendar.modle.bean.login;

/**
 * Created by Ronny on 2017/9/10.
 */

public class CityBean {

    /**
     * activeId : 13
     * name : 太原市
     * provinceId : 4
     */

    private int id;
    private String name;
    private int provinceId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(int provinceId) {
        this.provinceId = provinceId;
    }
}
